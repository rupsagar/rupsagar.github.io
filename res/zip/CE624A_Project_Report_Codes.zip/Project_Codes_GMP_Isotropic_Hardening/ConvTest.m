function [NotConv,ChkVal0] = ConvTest(ConvCrit,tol,ChkVal0,NotConv,Index,dr,Ru)

if strcmp(ConvCrit,"Relative Energy Increment")
    if Index==0
        ChkVal0 = Ru'*dr;
    else
        StrChk = Ru'*dr/ChkVal0;
        if StrChk<tol
            NotConv = false;
        end
    end
elseif strcmp(ConvCrit,"Energy Increment")
    StrChk = Ru'*dr;
    if StrChk<tol
        NotConv = false;
    end
    ChkVal0 = [];
end
    
end