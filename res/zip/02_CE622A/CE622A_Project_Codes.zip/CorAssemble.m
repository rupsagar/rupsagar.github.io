function [Ks,Ri] = CorAssemble(ElementType,MemCon,NodeXYk,Thetak,L0,Beta0,NumMem,NumTotalDOF,...
    NumStrDOF,NumMemDOF,MemDOF,KBCMap,BCMap,E,Area,MOI)

L = zeros(NumMem,1);
Q = zeros(NumMemDOF,NumMem);
Rg = zeros(NumTotalDOF,1);
KGLOBAL = zeros(NumTotalDOF);
Ks = zeros(NumStrDOF);

P = zeros(NumMem,1);
T = zeros(NumMemDOF,NumMemDOF,NumMem);

betai = zeros(NumMem,1);

for mem = 1:NumMem
    MemNode = MemCon(mem,:);
    Node1 = NodeXYk([2*MemNode(1)-1,2*MemNode(1)]);
    Node2 = NodeXYk([2*MemNode(2)-1,2*MemNode(2)]);
    ri = Node2-Node1;
    L(mem) = norm(ri);
    CS = ri/L(mem);
    uL = L(mem)-L0(mem);
    
    if strcmp(ElementType,'Truss') % FOR TRUSS ELEMENT
        t = [CS(1),CS(2),0;
            -CS(2),CS(1),0;
            0,0,1];
        T(:,:,mem) = [t,zeros(3);zeros(3),t];
        P(mem) = E(mem)*Area(mem)*uL/L0(mem);
        Q(:,mem) = T(:,:,mem)'*P(mem)*[-1,0,0,1,0,0]';
        KmLocal = E(mem)*Area(mem)/L0(mem)*[1,0,0,-1,0,0;
                                            0,0,0,0,0,0;
                                            0,0,0,0,0,0;
                                            -1,0,0,1,0,0;
                                            0,0,0,0,0,0;
                                            0,0,0,0,0,0];
        KgLocal = P(mem)/L(mem)*[1,0,0,-1,0,0;
                                 0,1,0,0,-1,0;
                                 0,0,0,0,0,0;
                                 -1,0,0,1,0,0;
                                 0,-1,0,0,1,0;
                                 0,0,0,0,0,0];
        Km = T(:,:,mem)'*(KmLocal)*T(:,:,mem);
        Kg = T(:,:,mem)'*(KgLocal)*T(:,:,mem);
        Kt = Km+Kg;
    elseif strcmp(ElementType,'Frame') % FOR FRAME ELEMENT
        betai(mem) = atan(ri(2)/ri(1));
        Theta = Thetak(MemNode);
        beta = Theta+Beta0(mem);
        num = @(j)cos(betai(mem))*sin(beta(j))-sin(betai(mem))*cos(beta(j));
        den = @(j)cos(betai(mem))*cos(beta(j))+sin(betai(mem))*sin(beta(j));
        ThetaL = @(j)atan(num(j)/den(j));

        dv = [uL;ThetaL(1);ThetaL(2)];

        Kv = [E(mem)*Area(mem)/L0(mem),0,0;
              0,4*E(mem)*MOI(mem)/L0(mem),2*E(mem)*MOI(mem)/L0(mem);
              0,2*E(mem)*MOI(mem)/L0(mem),4*E(mem)*MOI(mem)/L0(mem)];
        S = Kv*dv;

        z = [CS(2),-CS(1),0,-CS(2),CS(1),0]';
        r = [-CS(1),-CS(2),0,CS(1),CS(2),0]';
        A = ([0,0,1,0,0,0;0,0,0,0,0,1]-1/L(mem)*[z';z'])';
        B = [r';A'];  
        
        Q(:,mem) = B'*S;
        Km = B'*Kv*B;
        Kg = S(1)/L(mem)*(z*z')+(S(2)+S(3))/L(mem)^2*(r*z'+z*r');
        Kt = Km+Kg;
    end
    Rg(MemDOF(mem,:)) = Rg(MemDOF(mem,:))+Q(:,mem);
    for p = 1:NumMemDOF
        for q = 1:NumMemDOF
            KGLOBAL(MemDOF(mem,q),MemDOF(mem,p)) = KGLOBAL(MemDOF(mem,q),MemDOF(mem,p))+Kt(q,p);
        end
    end
end

Ks(:) = KGLOBAL(KBCMap);
Ri = Rg(BCMap);
end