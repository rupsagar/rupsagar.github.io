function State = ParamState0(FibState,fsec0)

State.NumTotalDataPts = 0;
State.FibState = FibState;
State.fsec = fsec0;

end